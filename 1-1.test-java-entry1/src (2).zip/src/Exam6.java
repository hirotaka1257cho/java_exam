public class Exam6 {
public static void main(String[] args) {
    String statement = "Steve Jobs said\t ""Stay Hungry. Stay Foolish.";
    System.out.println(statement);
}
}
