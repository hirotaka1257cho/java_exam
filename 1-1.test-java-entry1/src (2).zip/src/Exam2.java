public class Exam2 {
public static void main(String[] args) {
    String name;
    name = "横山広隆";

    System.out.println(name);
    System.out.println(name);
    System.out.println(name);
}
}
