public class Exam4 {
public static void main(String[] args) {
    int answer;
    answer = (int)(3.3 * 5.5);
    System.out.println("答えは" + answer + "です。");
}
}
